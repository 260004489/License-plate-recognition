# -*- coding: utf-8 -*-
"""
Created on Thu Nov 11 19:14:52 2021

@author: duanw
"""

import cv2
import numpy as np
import pytesseract


# Image reading
img = cv2.imread("1.jpg")

# Resize image
scale_percent = 80 # percent of original size
width = int(img.shape[1] * scale_percent / 100)
height = int(img.shape[0] * scale_percent / 100)
dim = (width, height)
resized = cv2.resize(img, dim, interpolation = cv2.INTER_AREA)
# =============================================================================
# cv2.imshow('Input', resized)
# #cv2.imshow('Output', img_output)
# cv2.waitKey()
# =============================================================================




# Projective transformation for the purpose of adjusting angle of license plate
rows, cols = resized.shape[:2]
src_points = np.float32([[0,0], [cols-1,0], [0,rows-1], [cols-1,rows-1]])
dst_points = np.float32([[0,0], [int(0.96*cols),0], [int(0.10*cols),rows-1], [cols-1,int(0.77*rows)]]) 
projective_matrix = cv2.getPerspectiveTransform(src_points, dst_points)
img_output = cv2.warpPerspective(resized, projective_matrix, (cols,rows))


#cv2.imshow('Input', resized)
# =============================================================================
# 
# cv2.imshow('Output', img_output)
# cv2.waitKey()
# 
# =============================================================================




# Convert to Grayscale Image
gray_image = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
# =============================================================================
# cv2.imshow('image',gray_image)
# cv2.waitKey(0)
# =============================================================================


# gaussian filter to remove the noise
gaussian = cv2.GaussianBlur(gray_image,(3,3),0)
# =============================================================================
# cv2.imshow("gaussian",gaussian)
# cv2.waitKey(0)
# =============================================================================

#Canny Edge Detection
canny_edge = cv2.Canny(gaussian, 100, 200)

# =============================================================================
# cv2.imshow("canny_edge",canny_edge)
# cv2.waitKey(0)
# =============================================================================




#Find contours based on Edges




contours, new  = cv2.findContours(canny_edge.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
contours=sorted(contours, key = cv2.contourArea, reverse = True)[:20]



# Initialize license Plate contour and x,y coordinates
contour_with_license_plate = None
license_plate = None
x = None
y = None
w = None
h = None

# Find the contour with 4 potential corners and creat ROI around it
for contour in contours:
        # Find Perimeter of contour and it should be a closed contour
        perimeter = cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, 0.05 * perimeter, True)

        if len(approx) == 4: #see whether it is a Rect
            contour_with_license_plate = approx
            x, y, w, h = cv2.boundingRect(contour)
            license_plate = gray_image[y:y + h, x:x + w]
            
            #cv2.imshow("canny",license_plate)
            break;
        
        
(thresh, license_plate) = cv2.threshold(license_plate, 110, 200, cv2.THRESH_BINARY)

text = pytesseract.image_to_string(license_plate, config='--psm 6')
print("Plate: ", text.upper())


#cv2.imshow("license_plate",license_plate)
#cv2.waitKey(0)
#cv2.destroyAllWindows()









