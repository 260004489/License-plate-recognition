# -*- coding: utf-8 -*-
"""
Created on Thu Nov 11 19:14:52 2021

@author: duanw
"""

import cv2
import numpy as np
import pytesseract
import re

# Image reading
img = cv2.imread("car.jpg")

# Resize image
scale_percent = 25 
width = int(img.shape[1] * scale_percent / 100)
height = int(img.shape[0] * scale_percent / 100)
dim = (width, height)
resized = cv2.resize(img, dim, interpolation = cv2.INTER_AREA)
# =============================================================================
# cv2.imshow('Input', resized)
# cv2.waitKey()
# =============================================================================


# Projective transformation for the purpose of adjusting angle of license plate
rows, cols = resized.shape[:2]
src_points = np.float32([[0,0], [cols-1,0], [0,rows-1], [cols-1,rows-1]])
dst_points = np.float32([[0,0], [int(0.96*cols),0], [int(0.03*cols),rows-1], [cols-1,int(0.93*rows)]]) 
projective_matrix = cv2.getPerspectiveTransform(src_points, dst_points)
img_output = cv2.warpPerspective(resized, projective_matrix, (cols,rows))
# =============================================================================
# cv2.imshow('Output', img_output)
# cv2.waitKey()
# =============================================================================



# Convert to Grayscale Image
gray_image = cv2.cvtColor(img_output, cv2.COLOR_BGR2GRAY)
# =============================================================================
# cv2.imshow('image',gray_image)
# cv2.waitKey(0)
# =============================================================================


# gaussian filter to remove the noise
gaussian = cv2.GaussianBlur(gray_image,(3,3),0)
# =============================================================================
# cv2.imshow("gaussian",gaussian)
# cv2.waitKey(0)
# =============================================================================


#Canny Edge Detection
canny_edge = cv2.Canny(gaussian, 100, 200)
# =============================================================================
# cv2.imshow("canny_edge",canny_edge)
# cv2.waitKey(0)
# =============================================================================



contours, new  = cv2.findContours(canny_edge.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
contours = sorted(contours, key = cv2.contourArea, reverse = True)[:20]
contour_with_license_plate = None
license_plate = None
x = None
y = None
w = None
h = None
for contour in contours:
        perimeter = cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, 0.05 * perimeter, True)
        if len(approx) == 4: 
            contour_with_license_plate = approx
            x, y, w, h = cv2.boundingRect(contour)
            license_plate = gray_image[y:y + h, x:x + w]
            break; 
# =============================================================================
# cv2.imshow("License plate",license_plate)
# cv2.waitKey(0)
# =============================================================================



(thresh, license_plate) = cv2.threshold(license_plate, 110, 200, cv2.THRESH_BINARY)
# =============================================================================
# cv2.imshow("license_plate",license_plate)
# cv2.waitKey(0)
# =============================================================================



text = pytesseract.image_to_string(license_plate, config='--psm 6')
text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\xff]', '', text)
text = text.strip('\n')
text = text.strip('\t') 
#print("License plate number: " + text)


cv2.rectangle(img_output, (x,y),(x+w,y+h),(0,255,0),2)
cv2.putText(img_output,text,(x,y-10),cv2.FONT_HERSHEY_COMPLEX,1,(0,255,0),2)
cv2.imshow("Result",img_output)
cv2.waitKey(0)










